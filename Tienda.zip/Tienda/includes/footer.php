<footer>
    <p>&copy; 2025 mini tienda virtual con php</p>
</footer>

</body>

</html>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilos.css"> 
    <title>FullRPM - Tienda de motos</title>
</head>
<body>
    <header>
        <div class="contenedor-header">
            <img src="img/FullRPM.png" alt="FullRPM Logo" class="logo">
            <nav>
                <a href="index.php">Inicio</a>
                <a href="tienda.php">Tienda</a>
            </nav>
        </div>
    </header>

<?php include('includes/header.php') ?>

<section class= "inicio">
    <div class= "container">
        <h1>Bienvenido a mi tienda con php </h1>
        <p> Compra tus productos favoritos</p>
        <a href= "tienda.php" class="btn"> Ver productos </a>
</div> 
</section>




<?php include('includes/footer.php')?>

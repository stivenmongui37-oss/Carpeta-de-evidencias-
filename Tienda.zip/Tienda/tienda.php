<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilos.css">
    <title>Tienda Virtual</title>
</head>
<body>
    <header>
        <div class="contenedor-header">
            <img src="img/FullRPM.png" alt="FullRPM Logo" class="logo">
            <nav>
                <a href="index.php">Inicio</a>
                <a href="tienda.php">Tienda</a>
            </nav>  
        </div>
    </header>

    <main>
        <section class="tienda">
            <h2>Nuestros productos</h2>
            <div class="productos">
                <div class="card">
                    <img src="img/Yamaha YZF-R6.png" alt="Yamaha YZF-R6">
                    <h3>Yamaha YZF-R6</h3>
                    <p class="precio">$75.000.000COP</p>
                    <form action="compra.php" method="POST">
                        <input type="hidden" name="producto" value="Yamaha YZF-R6">
                        <label for="cantidad1">Cantidad:</label>
                        <input type="number" id="cantidad1" name="cantidad" min="1" value="1">
                        <button type="submit" class="btn">Comprar</button>
                    </form>
                </div>

                <div class="card">
                    <img src="img/Kawasaki Ninja ZX-10R.png" alt="Kawasaki Ninja ZX-10R">
                    <h3>Kawasaki Ninja ZX-10R</h3>
                    <p class="precio">$110.000.000COP</p>
                    <form action="compra.php" method="POST">
                        <input type="hidden" name="producto" value="Kawasaki Ninja ZX-10R">
                        <label for="cantidad2">Cantidad:</label>
                        <input type="number" id="cantidad2" name="cantidad" min="1" value="1">
                        <button type="submit" class="btn">Comprar</button>
                    </form>
                </div>

                <div class="card">
                    <img src="img/Honda CBR1000RR-R Fireblade.png" alt="Honda CBR1000RR-R Fireblade">
                    <h3>Honda CBR1000RR-R Fireblade</h3>
                    <p class="precio">$130.000.000COP</p>
                    <form action="compra.php" method="POST">
                        <input type="hidden" name="producto" value="Honda CBR1000RR-R Fireblade">
                        <label for="cantidad2">Cantidad:</label>
                        <input type="number" id="cantidad3" name="cantidad" min="1" value="1">
                        <button type="submit" class="btn">Comprar</button>
                    </form>
                </div>

                <div class="card">
                    <img src="img/BMW S1000RR.png" alt="BMW S1000RR">
                    <h3>BMW S1000RR</h3>
                    <p class="precio">$145.000.000COP</p>
                    <form action="compra.php" method="POST">
                        <input type="hidden" name="producto" value="BMW S1000RR">
                        <label for="cantidad2">Cantidad:</label>
                        <input type="number" id="cantidad4" name="cantidad" min="1" value="1">
                        <button type="submit" class="btn">Comprar</button>
                    </form>
                </div>

                <div class="card">
                    <img src="img/Suzuki GSX-R1000.png" alt="Suzuki GSX-R1000">
                    <h3>Suzuki GSX-R1000</h3>
                    <p class="precio">$120.000.000COP</p>
                    <form action="compra.php" method="POST">
                        <input type="hidden" name="producto" value="Suzuki GSX-R1000">
                        <label for="cantidad2">Cantidad:</label>
                        <input type="number" id="cantidad5" name="cantidad" min="1" value="1">
                        <button type="submit" class="btn">Comprar</button>
                    </form>
                </div>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2025 Mini Tienda Virtual con PHP</p>
    </footer>
</body>
</html>

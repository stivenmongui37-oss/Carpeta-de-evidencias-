<?php include('includes/header.php'); ?>

<?php
// Verificar que el formulario se haya enviado
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Evitar errores si no existen los campos
    $producto = isset($_POST["producto"]) ? $_POST["producto"] : "";
    $cantidad = isset($_POST["cantidad"]) ? (int)$_POST["cantidad"] : 0;

    // Lista de precios
    $precio = [
        "Yamaha YZF-R6" => 75000000,
        "Kawasaki Ninja ZX-10R" => 110000000,
        "Honda CBR1000RR-R Fireblade" => 130000000,
        "BMW S1000RR" => 145000000,
        "Suzuki GSX-R1000" => 120000000,
    ];

    // Calcular total solo si el producto existe
    $total = isset($precio[$producto]) ? $precio[$producto] * $cantidad : 0;
?>
    <section class="compra">
        <h2>Resumen de la compra</h2>
        <div class="resumen">
            <p><strong>Producto:</strong> <?php echo htmlspecialchars($producto); ?></p>
            <p><strong>Cantidad:</strong> <?php echo $cantidad; ?></p>
            <p><strong>Total a Pagar:</strong> $<?php echo number_format($total, 0, ',', '.'); ?></p>
        </div>
        <a href="tienda.php" class="btn">Volver a la Tienda</a>
    </section>

<?php
} else {
    echo "<p>No se recibieron datos del formulario.</p>";
}
?>

<?php include('includes/footer.php'); ?>
